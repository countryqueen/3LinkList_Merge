/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package anothermerge;

import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Angel
 * 
‘******************************************************
‘***  Class Name: AnotherMerge
‘***  Class Author: Angelica
‘******************************************************
‘*** Purpose of the class (Why did you write this class?)
‘***: To display the merge sort with link list split in halves and thirds
‘******************************************************
‘*** Date 3/5/18
‘******************************************************

 */
public class AnotherMerge {

    /**
     * @param args the command line arguments
     * ‘******************************************************
‘***  Method Name: main
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: calls the other two methods to display results of mergesort using link list
‘*** Method Inputs:
‘*** List all the method parameters with their expected value ranges
‘*** Return value: none
‘******************************************************
‘*** Date 3/5/18

     */
    public static void main(String[] args)
    {
        showHalves();
        showThirds();
        
    }
    /*
    ‘***  Method Name: showHalves
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: to input the random numbers into the splitInTwo class and record speed time in miliseconds
‘*** Method Inputs: previous class (splitinTwo), 1000 random integers
‘*** no parameters
‘*** Return value: none
‘******************************************************
‘*** Date 3/5/18
    */
    public static void showHalves()
    {
    Random rand = new Random();
    //this will calculate the runtime in miliseconds

    long start = System.currentTimeMillis();
    //create the object of the linked list
    splitInTwo linked = new splitInTwo();
    //adding 1000 numbers to the linkedlist
    for(int i =0; i <=1000; i++)
    {
        linked.push(i);
        System.out.println("Linked list without sorting is : " + rand.nextInt(50));

    }

    //Using the merge sort
    linked.head = linked.mergeSort(linked.head);
    System.out.println("\n " );
    System.out.println("\n Sorted Linked List split in two: ");

    //got the run time in miliseconds from youtuber Telusko Learnigs
    long end = System.currentTimeMillis();
    long finalTime = end -start;
    System.out.println(finalTime);
    //this gets the average time from start to finish
    //print out the time in nanoseconds
    System.out.println(finalTime + " nanoseconds");
    System.out.println(" \n");

    }
/*
    ‘***  Method Name: showThirds
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: to input the random numbers into the splitThreeWays class and record speed time in miliseconds
‘*** Method Inputs: previous class (splitThreeWays), 1000 random integers
‘*** no parameters
‘*** Return value: none
‘******************************************************
‘*** Date 3/5/18
    */
    public static void showThirds()
    {
    //The following will be the linked list split into thirds
    //this will calculate the time for the run time in milliseconds
    long start3 = System.currentTimeMillis();

    splitThreeWays split = new splitThreeWays();

    Random rand1 = new Random();

    //adding the values
    for(int i =0; i <=50; i++)
    {
        split.push(i);
        System.out.println("Linked list without sorting is : " + rand1.nextInt(50));
    }

    //used codejava.net to use the collections operation to make 
    //the numbers out of order instead of using random
    System.out.println("Linked list without sorting is : " );
    split.printList(split.head);

    //Using the merge sort
    split.head = split.mergeSort(split.head);
    System.out.println("\n Sorted Linked List split in three: ");
    split.printList(split.head);

    //got the run time in miliseconds from youtuber Telusko Learnigs
    long end3 = System.currentTimeMillis();
    //subtract the end from the start time!
    long finalTime3 = end3 - start3;
    System.out.println(finalTime3);
    //this gets the average time from start to finish
    //print out the time in nanoseconds
    long value3 = System.currentTimeMillis();
    System.out.println(value3 + " nanoseconds");

    }

}
