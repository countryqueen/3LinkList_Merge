/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package anothermerge;

/**
 *
 * @author Angel
 * 
‘******************************************************
‘***  Class Name: splitThreeWays
‘***  Class Author: Angelica
‘******************************************************
‘*** Purpose of the class :
‘*** implement link list split in thirds using a merge sort
‘******************************************************
‘*** Date 3/5/19
‘******************************************************

 */
//this linked list will be split into three ways
public class splitThreeWays
{
    node head = null;
    
     /*
    ‘******************************************************
‘***  Class Name: node 
‘***  Class Author Angelica
‘******************************************************
‘*** Purpose of the class: this is an inner class to define my variables and create a setter
    also I wanted to try something new! instead of using a constructor
‘***
‘******************************************************
‘*** Date 3/5/18
‘******************************************************
    
    */
    public static class node 
    {
        //here are my variables
        int value;
	node nextLink;

        //this is my setter
	public node(int value) 
	{
            this.value = value;
	}
    }
    
    /*   ‘******************************************************
‘***  Method Name: Compare
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method compares the first node, second node, and third node of the three lists
‘*** parameter: node a and node b and node c
‘*** Return value: either a or b or c of the following link
‘*** If this is a function list the return data type and the expected range of 
‘*** values to be returned.
‘******************************************************
‘*** Date 3/5/18
*/
     //now we will set the three list to null,
    //comparison and recursive algorithm will take place
    node Compare(node a1, node b1, node c1)
    {
        node result = null;
	if (a1 == null)
        {
            return b1;
        }    
	if (b1 == null)
        {
            return c1;
        }
        if (c1 == null)
        {
            return a1;
        }
        //split it into three and use recursion to call on itself
        // Pick either a, b, or c and recurse!!
	if (a1.value <= b1.value && a1.value <=c1.value) 
	{
            result = a1;
            result.nextLink = Compare(a1.nextLink, b1, c1);
        } 
        else if(b1.value <= c1.value && b1.value <= a1.value)
	{
            result = b1;
            result.nextLink = Compare(a1, b1.nextLink, c1);
	}
        else if(c1.value <= a1.value && c1.value <=b1.value)   
        {
            result = c1;
            result.nextLink = Compare(a1, b1,c1.nextLink);
        }
        return result;
    }
   
    /*   ‘******************************************************
‘***  Method Name: mergeSort
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method compares the first node, the second node and third node aka the heads
‘*** parameter: node h
‘*** Return value:return h and sortedList!!
‘*** If this is a function list the return data type and the expected range of 
‘*** values to be returned.
‘******************************************************
‘*** Date 3/5/18
*/
   
    node mergeSort(node h) 
    {
    // scenario 1 if head is null or is the nextLink then return it
        if (h == null || h.nextLink == null ||  h.nextLink.nextLink== null) 
        {
            return h;
	}
       
        // retrieve middle of the list
	node Third = findThird(h);
	node nextofThird = Third.nextLink;
        node theCenter = Third.nextLink.nextLink;
       
        // set the next of middle node to null
	Third.nextLink = null;
	// Apply mergeSort on left list
	node left = mergeSort(h);

	// Apply mergeSort on right list
	node right = mergeSort(nextofThird);
        
        //Apply mergeSort on center of list
        node center = mergeSort(theCenter);

	// Merge the left and right lists
        node sortedlist = Compare(left, right,center);
	return sortedlist;
    }
    
    /*   ‘*****************
    *************************************
‘***  Method Name: findThird
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: use nodes to split it down to thirds
‘*** parameter: node h
‘*** Return value: either a or b of the following link
‘*** If this is a function list the return data type and the expected range of 
‘*** values to be returned.
‘******************************************************
‘*** Date 3/5/18
*/
   
    node findThird(node h) 
    {
    //Base case
	if (h == null)
        {
            
            return h;
        }
       
        node pointer1 = h.nextLink;
        node pointer2 = h.nextLink.nextLink;
        node pointer3 = h;
		
	//three pointers to be find their match
        
        //this scenario will have the first node not be null
        //then it moves on to the following link and moves down the list
        //otherwise it will return the other two pointers
	while (pointer1 != null)
	{
            pointer1 = pointer1.nextLink;
            if(pointer1!=null)
            {
                pointer3 = pointer3.nextLink;
                pointer2 = pointer2.nextLink;
		pointer1=pointer1.nextLink;
            }
            else 
            {
                return pointer3;
            }
	}
            return pointer2;
            
    }
    
      
    /*   ‘******************************************************
‘***  Method Name: Push
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: create the new node by moving the old list off the new node
‘*** parameter: new_data this is an integer
‘*** Return value:void
‘******************************************************
‘*** Date 3/5/18
*/
     public void push(int new_data) 
    {
        node new_node = new node(new_data);
	/* link the old list off the new node */
        new_node.nextLink = head;
	/* move the head to point to the new node */
	head = new_node;
    }
  /*   ‘******************************************************
‘***  Method Name: printList
‘***  Method Author: Angelica
‘******************************************************
‘*** Purpose of the Method: displays the head of the node and the following link. aka showing the list
‘*** parameter: node headref
‘*** Return value: void
‘*** If this is a function list the return data type and the expected range of 
‘*** values to be returned.
‘******************************************************
‘*** Date 3/5/18
*/
    void printList(node headref) 
    {
        //while loop is used because it is unknown how many times a
        //head reference will be null
	while (headref != null) 
	{
            //display the list!
            System.out.print(headref.value + " ");
            headref = headref.nextLink;
	}
    }
    
    
}
