/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package show3list;

/**
 *
 * @author aj035
 *  * ‘******************************************************
‘***  Class Name: MergeSortBoss
‘***  Class Author Angelica
‘******************************************************
‘***split the link list in two, compare them find the smallest number 
* apply the merge sort to the link list and put them back together
* to make one list
‘***
‘******************************************************
‘*** Date 3/6/18
‘******************************************************
 */
public class MergeSortBoss 
{
    TheLinkList1 root = null;
    
    
 /*   
‘******************************************************
‘***  Method Name add
‘***  Method Author Angelica
‘******************************************************
‘*** Purpose of the Method: builds a random value link list on the original
‘*** Method Inputs: the start of the node
‘*** List all the method parameters: int value
‘*** Return value:void
‘******************************************************
‘*** Date 3/6/18
‘******************************************************
*/
    public void addToLL (int value)
    {
        TheLinkList1 temp = new TheLinkList1();
        temp.value = value;
        
        if(root == null)
        {
            root = temp;
            return;
        }
        temp.nextLink = root;
        root = temp;
    }
    
     /*   
‘******************************************************
‘***  Method Name: recursion
‘***  Method Author Angelica
‘******************************************************
‘*** Purpose of the Method: calls the merge sort method recursively
‘*** Method Inputs: the root
‘*** List all the method parameters: none
‘*** Return value:void
‘******************************************************
‘*** Date 3/6/18
‘******************************************************
*/
    public void recursion()
    {
        root = mergeSort(root);
    }
    
         /*   
‘******************************************************
‘***  Method Name TheLinkList mergeSort
‘***  Method Author Angelica
‘******************************************************
‘*** Purpose of the Method: utility function to perform the merge sort
‘*** Method Inputs: the root
‘*** List all the method parameters: myLL
‘*** Return value: myLL
‘******************************************************
‘*** Date 3/6/18
‘******************************************************
*/
    //function is private so that other classes cannot have access to it
    private TheLinkList1 mergeSort(TheLinkList1 myLL)
    {
        boolean isRight = true;
        
        //sets the right and left to empty values
        TheLinkList1 right = null;
        TheLinkList1 left = null;
        
        while(myLL != null)
        {
            TheLinkList1 temp;
            //create a temporary node
            
            //set the temporary node to your link list
            temp = myLL;
            //then set it to the following link
            myLL = myLL.nextLink;
            temp.nextLink = null;
            
            //start comparing
            //if the right side is true then set the link to the right
            if(isRight)
            {
                temp.nextLink = right;
                right = temp;
                isRight = !isRight;
            }
            //otherwise set the link to left
            else
            {
                temp.nextLink = left;
                left = temp;
                isRight = !isRight;
            } 
        }
        //if this list is not empty call the merge sort function
        if(right != null && right.nextLink != null)
        {
            right = mergeSort(right);
        }
        if(left != null && left.nextLink != null)
        {
            left = mergeSort(left);
        }
        
        //put the two list back together as one list when the list is empty
        TheLinkList1 end = null;
        //while loop is used to continuously compare the numbers ont he left and the right side
        while (right != null || left != null)
        {
            if(right == null)
            {
                if(end != null)
                {
                    end.nextLink =left;
                    left = null;
                }
            }
            else if(left == null)
            {
                if(end != null)
                {
                    end.nextLink = right;
                    right = null;
                }
            }
            //comparing the nodes of left and right
            else if(right.value < left.value)
            {
                if(myLL == null)
                {
                    myLL = right;
                    right = right.nextLink;
                    myLL.nextLink = null;
                    end = myLL;
                }
                else
                {
                    //set the link list to temporary node
                    TheLinkList1 temp;
                    temp = right;
                    right = right.nextLink;
                    temp.nextLink = null;
                    end.nextLink = temp;
                    end = temp;
                }
            }
            else //this is for the left list, if its smaller then it will be on the list
            {
                if(myLL == null)
                {
                    myLL = left;
                    left = left.nextLink;
                    myLL.nextLink = null;
                    end = myLL;
                }
                else
                {
                    TheLinkList1 temp;
                    temp = left;
                    left = left.nextLink;
                    temp.nextLink = null;
                    end.nextLink = temp;
                    end = temp;
                } 
            }
        }
        return myLL;
        
        
    }

         /*   
‘******************************************************
‘***  Method Name: print
‘***  Method Author Angelica
‘******************************************************
‘*** Purpose of the Method: print out the list
‘*** Method Inputs: the root
‘*** Return value: void
‘******************************************************
‘*** Date 3/6/18
‘******************************************************
*/
    public void print()
    {
        String output = recPrint(root, 1, " ");
        System.out.println(output);
    }
    
             /*   
‘******************************************************
‘***  Method Name: recprint
‘***  Method Author Angelica
‘******************************************************
‘*** Purpose of the Method: print out the list recursively
‘*** Method Parameters: TheLinkList myLL, int count, String output
‘*** Return value: output
‘******************************************************
‘*** Date 3/6/18
‘******************************************************
*/
    
    private String recPrint(TheLinkList1 myLL, int count, String output)
    {
        if(myLL == null)
        {
            return output;
        }
        output += " "+ myLL.value;
        if(count == 10)
        {
            output += "\n";
            count = 0;
        }
        return output = recPrint(myLL.nextLink, ++count, output);
    }
}
