/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package show3list;

/**
 *
 * @author aj035
 */
public class TheLinkList 
{
//    **
// *
// * @author aj035
// * ‘******************************************************
//‘***  Class Name: TheLinkList
//‘***  Class Author Angelica
//‘******************************************************
//‘*** Purpose of the class The node class must be
//* outside of the other classes.
//‘***
//‘******************************************************
//‘*** Date 3/6/18
//‘******************************************************
//
// *
    //here are my variables
    private int value;
    private TheLinkList nextLink;

    /**
     * @return the value
     */
    public int getValue() {
        return value;
    }

    /**
     * @param value the value to set
     */
    public void setValue(int value) {
        this.value = value;
    }

    /**
     * @return the nextLink
     */
    public TheLinkList getNextLink() {
        return nextLink;
    }

    /**
     * @param nextLink the nextLink to set
     */
    public void setNextLink(TheLinkList nextLink) {
        this.nextLink = nextLink;
    }
    public TheLinkList(int num)
    {
        this.value = num;
	this.nextLink = null;
    }
}
    

