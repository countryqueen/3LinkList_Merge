/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package show3list;

/**
 *
 * @author aj035
 */
public class thirdMerge 
{
     //helped third merge sort from makeinjava.com
    //http://www.makeinjava.com/merge-two-sorted-singly-linked-lists-java-example-recursive/
    /*
    /*   
‘******************************************************
‘***  Method Name: TheLinkList merge
‘***  Method Author Angelica
‘******************************************************
‘*** Purpose of the Method: add random numbers to link list
* prints the list unsorted and then sorted
‘******************************************************
‘*** Date 3/6/18
‘******************************************************
*/
  /*  Create merge method, taking head1 and head2 as method parameter
merge(Node head1, Node head2)
Create variable mergedList, which will point to head of merge linked list
Let us look into recursive merge method
If we reached end of first linked list
return second linked list
so that, mergedList start point to second linked list
If we reached end of second linked list
return first linked list
so that, mergedList start pointing first linked list
If we are here, then compare
Check head1.data < head2.data
mergedList point to head1
now lets move ahead in linked list
head1.next and head2
We are here, head1.data >= head2.data
mergeList points to head2
lets move ahead in linked list
head1 and head2.next/*
return mergedList [resultant linked list]
    
    */
    //this merge method will take all three heads
    public static TheLinkList merge(TheLinkList head1, TheLinkList head2, TheLinkList head3)
    {
        TheLinkList mergedList = null;
        
        //returns the null values
        if(head1 == null) 
        {
            return head3;
        }
        if(head2 == null) 
        {
            return head1;
        }
        if(head3 == null)
        {
            return head2;
        }
        //head1 is smaller than head2//head1 is smaller than head3
        if(head1.getValue() <= head2.getValue()&& head1.getValue() <= head3.getValue()) 
        {
            //point to smaller element
            mergedList = head1;			
            mergedList.setNextLink(merge(head1.getNextLink(), head2, head3));
        } 
        
        //head1 greater than head2 and head2 less than head3
        else if(head1.getValue() >= head2.getValue() && head2.getValue()<= head3.getValue() )
        {
            //point to smaller element
            mergedList = head2;			
            mergedList.setNextLink(merge(head1, head2.getNextLink(), head3));
        }
        //head1 greater than head3 and head 2 is greater than 3
        else if(head1.getValue() >= head3.getValue() && head2.getValue() >= head3.getValue()) 
        { //head1 is large, so pass h
            //point to smaller element
            mergedList = head3;
            //head2 is already consider
            //now process next node of head2
            mergedList.setNextLink(merge(head1, head2, head3.getNextLink()));
        }
        //head2 less than head1 and head2 less than 3
//        else if (head2.getValue() <= head1.getValue()&& head2.getValue() <= head3.getValue())
//        {
//            mergedList = head3;			
//            mergedList.setNextLink(merge(head1, head2.getNextLink(), head3));
//        }
        //head2 greaater than head1
        else if (head2.getValue() >= head1.getValue())
        {
            mergedList = head2;			
            mergedList.setNextLink(merge(head1.getNextLink(), head2, head3));
        }
        //head2 is greater than head3
        else if (head2.getValue() >= head3.getValue())
        {
            mergedList = head3;			
            mergedList.setNextLink(merge(head1, head2, head3.getNextLink()));
        }
        //head3 is less than head1 and head3 is less than head2
         else if (head3.getValue() <= head1.getValue()&& head3.getValue() <= head2.getValue())
        {
            mergedList = head3;			
            mergedList.setNextLink(merge(head1, head2, head3.getNextLink()));
        }
        //head3 greaater than head1
        else if (head3.getValue() >= head1.getValue())
        {
            mergedList = head1;			
            mergedList.setNextLink(merge(head1.getNextLink(), head2, head3));
        }
        //head3 is greater than head2
        else if (head3.getValue() >= head2.getValue())
        {
            mergedList = head2;			
            mergedList.setNextLink(merge(head1, head2.getNextLink(), head3));
        }
        return mergedList;
    }
    public static void insert(TheLinkList head, int value)
    {
        while(head.getNextLink() != null)
        { 
            head = head.getNextLink();
        }
        head.setNextLink(new TheLinkList(value));
    }
	
	public static void print(TheLinkList head) 
        {
            while(head != null) 
            {
                System.out.printf("%d ", head.getValue());
                head = head.getNextLink();
            }
            System.out.println("");		
	}
    
}
