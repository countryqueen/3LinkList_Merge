/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package show3list;

import java.util.Random;

/**
 *
 * @author aj035
 */
public class Show3List {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       long start = System.currentTimeMillis();
        //this call the class for splitting link list in two
       MergeSortBoss boss = new MergeSortBoss();
       Random rand = new Random();
       
       
       for(int i = 0; i<10; i++)
       {
           boss.addToLL(rand.nextInt(50000));
       }
       
       System.out.println("Numbers unsorted with two link list: ");
       boss.print();
       boss.recursion();
       System.out.println("Numbers sorted with two link list: ");
       boss.print();
       
        System.out.println("  ");
     //got the run time in miliseconds from youtuber Telusko Learnigs
    long end = System.currentTimeMillis();
    long finalTime = end -start;
    System.out.println(finalTime);
    //this gets the average time from start to finish
    //print out the time in nanoseconds
    System.out.println(finalTime + " nanoseconds");
    System.out.println(" \n");
       
         //       this calls the class for splitting the link list in three
       thirdMerge third = new thirdMerge();
       Random rand1 = new Random();
       
       TheLinkList head1 = new TheLinkList(rand1.nextInt(2000));
       for(int count = 0; count < 10; count++)
       {
            third.insert(head1,rand1.nextInt(2000));
       }

        System.out.printf("Linked list 1 is : ");
        third.print(head1);

        
        TheLinkList head2 = new TheLinkList(rand1.nextInt(2000));
        for(int count = 0; count < 10; count++)
        {
            third.insert(head2,rand1.nextInt(2000));
        }

        System.out.printf("Linked list 2 is : ");
        third.print(head2);
        

        TheLinkList head3 = new TheLinkList(rand1.nextInt(2000));
        for(int count = 1; count <  10; count++)
        {
            third.insert(head3,rand1.nextInt(2000));
        }

        System.out.printf("Linked list 3 is : ");
        third.print(head3);
        
        long start3 = System.currentTimeMillis();

       TheLinkList mergedList = thirdMerge.merge(head1, head2, head3);
       System.out.println("Numbers sorted with three link list: ");
       thirdMerge.print(mergedList);
       //got the run time in miliseconds from youtuber Telusko Learnigs
        long end3 = System.currentTimeMillis();
        //subtract the end from the start time!
        long finalTime3 = end3 - start3;
        System.out.println(finalTime3);
        //this gets the average time from start to finish
        //print out the time in nanoseconds
        long value3 = System.currentTimeMillis();
        System.out.println(value3 + " nanoseconds");
    }
    
}
